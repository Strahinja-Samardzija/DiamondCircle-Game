package model.game_validation;

public class PlayerFiguresValidation {

}
