package model.figures;

public interface ILevitating {

}
