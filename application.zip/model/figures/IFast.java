package model.figures;

public interface IFast {

}
