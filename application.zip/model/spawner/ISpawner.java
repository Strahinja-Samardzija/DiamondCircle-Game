package model.spawner;

import java.util.List;

import model.path.Tile;

public interface ISpawner {

	List<Tile> spawn();

}