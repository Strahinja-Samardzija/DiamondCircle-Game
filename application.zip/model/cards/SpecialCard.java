package model.cards;

public class SpecialCard implements ICard, ISpecialCard {
	
}
