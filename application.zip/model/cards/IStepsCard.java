package model.cards;

import model.cards.CardDeque.STEPS;

public interface IStepsCard {

	STEPS getSteps();
}
