package model.cards;

public interface ICard {

}
