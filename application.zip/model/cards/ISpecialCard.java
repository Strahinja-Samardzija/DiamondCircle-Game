package model.cards;

public interface ISpecialCard {

}
