package controller.signals;

public class DrawCardSignal {

	public DrawCardSignal() {
		// Used for synchronization only
	}

}
